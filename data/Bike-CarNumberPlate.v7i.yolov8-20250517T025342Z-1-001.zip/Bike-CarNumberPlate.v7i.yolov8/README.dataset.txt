# Bike&CarNumberPlate > 2024-02-18 10:01am
https://universe.roboflow.com/indiannumberplatesdetection/bike-carnumberplate

Provided by a Roboflow user
License: CC BY 4.0

